=======
virlsdk
=======


A python SDK wrapper for Cisco's VIRL API.

Description
===========

This SDK wraps the following API functions:
   1. Get the current simulations
   2. Launch a simulation
   3. Stop a simulation
   4. Get the status of a simulation

Please see: http://virl-dev-innovate.cisco.com/api.docs.php, for details about
the APIs themselves

Note
====
Please see the docs dir.
